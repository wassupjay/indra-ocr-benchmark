# Review package

Code, aggregate book metrics and original synthetic control images/text only.
No source book PDF, book page images, extracted book text, book predictions, model weights, credentials or font files are included.
The article remains a draft. Public annotated-document results are pending download access.
The book cannot be reproduced from this archive alone: its exact input PDF is not distributed.
