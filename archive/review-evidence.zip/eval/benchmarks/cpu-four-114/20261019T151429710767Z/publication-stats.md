# OCR comparison: publication statistics

Reference status: unverified PDF text layer; scores measure agreement, not verified accuracy.

## Recognition agreement

| Engine | WER | WER page-bootstrap 95% interval | CER | Word edits | Substitutions | Deletions | Insertions | Exact-text pages |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| indra | 2.057% | 1.798%–2.340% | 0.585% | 1245 | 1153 | 38 | 54 | 3/114 |
| tesseract | 2.462% | 2.217%–2.731% | 0.679% | 1490 | 1296 | 65 | 129 | 0/114 |
| easyocr | 15.968% | 15.234%–16.750% | 7.430% | 9665 | 5370 | 1853 | 2442 | 0/114 |
| paddleocr_tiny | 3.070% | 2.622%–3.541% | 0.763% | 1858 | 1319 | 525 | 14 | 10/114 |

## Recorded application throughput

| Engine | Pages/min | Median full pass (s) | Pass range (s) | First-pass page p50 (s) | First-pass page p95 (s) | Initialization (s) | Failures |
|---|---:|---:|---:|---:|---:|---:|---:|
| indra | 207.48 | 32.97 | 32.90–33.73 | 0.312 | 0.377 | 0.53 | 0 |
| tesseract | 58.30 | 117.31 | 116.69–117.57 | 1.076 | 1.390 | 0.04 | 0 |
| easyocr | 3.51 | 1946.20 | 1943.70–1960.17 | 17.629 | 20.649 | 3.56 | 0 |
| paddleocr_tiny | 77.18 | 88.63 | 88.48–89.11 | 0.806 | 0.962 | 1.48 | 0 |

Page latency percentiles in this table use the first pass only. Newer results also preserve later per-page timings in pass_details; historical runs may contain pass totals only.
Three pass totals describe repeatability, not a reliable speed confidence interval. Initialization excludes the first warmup call.
Resource scope is recorded separately from inference-only timing. Resource profiles for a different run or a small sample must not be relabeled as full-run memory measurements. Historical resources cannot be reconstructed when no monitoring record exists.

## Paired accuracy differences

Negative differences favor the left engine. Intervals are descriptive within-sample bootstrap estimates, not evidence of performance across other independent documents.

| Left vs right | WER difference (percentage points) | Paired 95% interval | Page wins / ties / losses |
|---|---:|---:|---:|
| indra vs tesseract | -0.4048 | -0.4986–-0.3180 | 92 / 12 / 10 |
| indra vs easyocr | -13.9114 | -14.5289–-13.3063 | 114 / 0 / 0 |
| indra vs paddleocr_tiny | -1.0128 | -1.3506–-0.6898 | 71 / 9 / 34 |
| tesseract vs easyocr | -13.5066 | -14.1267–-12.8982 | 113 / 1 / 0 |
| tesseract vs paddleocr_tiny | -0.6080 | -0.9654–-0.2690 | 57 / 8 / 49 |
| easyocr vs paddleocr_tiny | 12.8986 | 12.3560–13.4742 | 0 / 0 / 114 |

## What can be claimed

These are measured results on the same 114 pages. Reference: unverified PDF text layer; scores measure agreement, not verified accuracy.
Do not call 100−WER a probability of correct recognition. Edit rates include insertions and can exceed 100%.
Do not claim a general winner from these results. Diverse independent documents and validated runtime configurations remain required for broader claims.
Tesseract CLI starts once per page; Python engines remain resident. Reported throughput includes that integration difference.
Model versions, settings and hardware details are in publication-stats.json. Reproduction commands and limitations are in BENCHMARK.md.
