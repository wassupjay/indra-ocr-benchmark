# Known-text control: completed quality check

Reference text is known by construction. All models saw the same three images.

| Engine | Reference words (repeated across variants) | Word edits | Character edits | WER | CER |
|---|---:|---:|---:|---:|---:|
| indra | 372 | 0 | 0 | 0.000% | 0.000% |
| tesseract | 372 | 0 | 0 | 0.000% | 0.000% |
| paddleocr | 372 | 0 | 0 | 0.000% | 0.000% |

Saved PaddleOCR predictions from the interrupted full control attempt were supplemented with separately completed single-image diagnostics using the same model names and default settings. See the per-image provenance. No combined throughput is claimed.

This is a small clean-print sanity check. Three font/blur variants repeat the same 124-word passage. Zero edits here do not imply general OCR accuracy or equivalence on real documents.
Raw predictions and their hashes are listed in quality-validation.json. The public annotated-document evaluation remains pending download access.
