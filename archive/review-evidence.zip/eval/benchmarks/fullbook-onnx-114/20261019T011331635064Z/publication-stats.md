# OCR comparison: publication statistics

Reference status: unverified PDF text layer; scores measure agreement, not verified accuracy.

## Recognition agreement

| Engine | WER | WER page-bootstrap 95% interval | CER | Word edits | Substitutions | Deletions | Insertions | Exact-text pages |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| indra | 2.057% | 1.798%–2.340% | 0.585% | 1245 | 1153 | 38 | 54 | 3/114 |
| tesseract | 2.462% | 2.217%–2.731% | 0.679% | 1490 | 1296 | 65 | 129 | 0/114 |
| paddleocr | 2.093% | 1.764%–2.443% | 0.619% | 1267 | 1215 | 48 | 4 | 15/114 |

## Recorded application throughput

| Engine | Pages/min | Median full pass (s) | Pass range (s) | First-pass page p50 (s) | First-pass page p95 (s) | Initialization (s) | Failures |
|---|---:|---:|---:|---:|---:|---:|---:|
| indra | 32.38 | 211.27 | 210.86–212.21 | 1.916 | 2.097 | 8.45 | 0 |
| tesseract | 56.91 | 120.20 | 118.61–121.08 | 1.102 | 1.404 | 0.67 | 0 |
| paddleocr | 2.89 | 2369.68 | 2352.94–2371.19 | 21.909 | 26.899 | 5.51 | 0 |

Page latency percentiles in this table use the first pass only. Newer results also preserve later per-page timings in pass_details; historical runs may contain pass totals only.
Three pass totals describe repeatability, not a reliable speed confidence interval. Initialization excludes the first warmup call.
Resource scope is recorded separately from inference-only timing. Resource profiles for a different run or a small sample must not be relabeled as full-run memory measurements. Historical resources cannot be reconstructed when no monitoring record exists.

## Paired accuracy differences

Negative differences favor the left engine. Intervals are descriptive within-sample bootstrap estimates, not evidence of performance across other independent documents.

| Left vs right | WER difference (percentage points) | Paired 95% interval | Page wins / ties / losses |
|---|---:|---:|---:|
| indra vs tesseract | -0.4048 | -0.4986–-0.3180 | 92 / 12 / 10 |
| indra vs paddleocr | -0.0363 | -0.2664–0.1911 | 48 / 10 / 56 |
| tesseract vs paddleocr | 0.3684 | 0.1283–0.6101 | 35 / 8 / 71 |

## What can be claimed

These are measured results on the same 114 pages. Reference: unverified PDF text layer; scores measure agreement, not verified accuracy.
Do not call 100−WER a probability of correct recognition. Edit rates include insertions and can exceed 100%.
Do not claim a general winner from these results. Diverse independent documents and validated runtime configurations remain required for broader claims.
Tesseract CLI starts once per page; Python engines remain resident. Reported throughput includes that integration difference.
Model versions, settings and hardware details are in publication-stats.json. Reproduction commands and limitations are in BENCHMARK.md.
