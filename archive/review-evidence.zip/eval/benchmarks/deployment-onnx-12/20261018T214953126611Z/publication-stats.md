# OCR comparison: publication statistics

Reference status: unverified PDF text layer; scores measure agreement, not verified accuracy.

## Recognition agreement

| Engine | WER | WER page-bootstrap 95% interval | CER | Word edits | Substitutions | Deletions | Insertions | Exact-text pages |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| indra | 2.489% | 1.211%–4.094% | 0.986% | 136 | 112 | 2 | 22 | 1/12 |
| tesseract | 2.635% | 1.603%–4.014% | 1.239% | 144 | 114 | 15 | 15 | 0/12 |
| paddleocr | 2.489% | 1.129%–3.938% | 1.129% | 136 | 122 | 12 | 2 | 4/12 |

## Recorded application throughput

| Engine | Pages/min | Median full pass (s) | Pass range (s) | First-pass page p50 (s) | First-pass page p95 (s) | Initialization (s) | Failures |
|---|---:|---:|---:|---:|---:|---:|---:|
| indra | 35.27 | 20.42 | 9.38–21.08 | 0.301 | 2.057 | 0.77 | 0 |
| tesseract | 67.57 | 10.66 | 10.58–10.70 | 0.953 | 1.219 | 0.73 | 0 |
| paddleocr | 3.32 | 216.73 | 215.71–217.64 | 18.951 | 24.017 | 2.00 | 0 |

Page latency percentiles in this table use the first pass only. Newer results also preserve later per-page timings in pass_details; historical runs may contain pass totals only.
Three pass totals describe repeatability, not a reliable speed confidence interval. Initialization excludes the first warmup call.
Resource scope is recorded separately from inference-only timing. Resource profiles for a different run or a small sample must not be relabeled as full-run memory measurements. Historical resources cannot be reconstructed when no monitoring record exists.

## Paired accuracy differences

Negative differences favor the left engine. Intervals are descriptive within-sample bootstrap estimates, not evidence of performance across other independent documents.

| Left vs right | WER difference (percentage points) | Paired 95% interval | Page wins / ties / losses |
|---|---:|---:|---:|
| indra vs tesseract | -0.1464 | -0.4984–0.3824 | 8 / 2 / 2 |
| indra vs paddleocr | 0.0000 | -0.9123–0.8917 | 6 / 1 / 5 |
| tesseract vs paddleocr | 0.1464 | -0.7784–0.9977 | 4 / 1 / 7 |

## What can be claimed

These are measured results on the same 12 pages. Reference: unverified PDF text layer; scores measure agreement, not verified accuracy.
Do not call 100−WER a probability of correct recognition. Edit rates include insertions and can exceed 100%.
Do not claim a general winner from these results. Diverse independent documents and validated runtime configurations remain required for broader claims.
Tesseract CLI starts once per page; Python engines remain resident. Reported throughput includes that integration difference.
Model versions, settings and hardware details are in publication-stats.json. Reproduction commands and limitations are in BENCHMARK.md.
