# CPU OCR Benchmark: Indra vs Tesseract, EasyOCR and PaddleOCR

*Four engines, one Windows CPU, three charts.*

Indra led this run on speed and reference-text agreement. Tesseract used the least RAM. Here are the results without the spreadsheet.

*Disclosure: This article and its charts were prepared with AI assistance using recorded benchmark results.*

## The test, briefly

All four engines read the same 114 saved page images from one English book, at 200 DPI. Each had a warmup and three measured passes, with four inference threads requested. No GPU was used.

The PC had an i7-12700K and about 96 GiB of RAM: a well-equipped desktop, not an entry-level-PC test. Models: Indra 0.3.2, Tesseract 5.5.3, EasyOCR 1.7.2 (CPU, CRAFT/english_g2, dynamic quantization), and PP-OCRv6 Tiny through ONNX Runtime CPU. These are tested configurations, not each engine's best possible tuned setup.

## 1. Speed: Indra finished fastest

![CPU OCR throughput: Indra 207.48, Tesseract 58.30, PaddleOCR Tiny 77.18 and EasyOCR 3.51 pages per minute](chart-speed.png)

*Higher is faster. Chart rendered from saved measurements with AI assistance.*

Throughput includes image decoding and Tesseract's per-page CLI startup. PDF rendering, initial loading, warmup, scoring and writes are excluded.

## 2. Word errors: the reference matters

![Word error rates against two unverified references; Indra has the lowest rate against both](chart-word-errors.png)

*Lower means closer text agreement. Filled bars use PDF text; outlined bars use the supplied AI-assisted transcription. Chart prepared with AI assistance.*

WER counts changed, missing and extra words. Case and punctuation count. Neither reference is fully independently verified, so this chart does not establish verified accuracy. The transcription's six uncertainty markers use supplied best readings. Excluding its 15 flagged pages kept the same engine ranking; quote-style normalization also preserved that ranking.

## 3. Memory: Tesseract was the lightest

![Peak sampled worker RAM: Indra 0.33 GiB, Tesseract 0.11 GiB, PaddleOCR Tiny 1.32 GiB and EasyOCR 9.77 GiB](chart-memory.png)

*Lower uses less RAM. Whole-worker memory includes loading and warmup; it has a broader scope than throughput. Chart prepared with AI assistance.*

## What I would take from this

- **Indra:** strongest speed and text-agreement result in this run.
- **Tesseract:** smallest measured memory footprint.
- **PaddleOCR Tiny:** second-fastest; EasyOCR was slower and used more RAM in the configuration tested.

All engines completed without execution failures. Saved outputs were checked, and each engine produced identical normalized text across its three passes.

**The limits:** One book cannot establish a universal winner. Indra previously measured 32.38 pages/min with matching model hashes; that cross-session speed difference remains unexplained. Both references still need independent verification. Nothing here measures handwriting, other languages or a low-memory PC.

[Full methods and detailed results](MEDIUM_FULL_METHODS.md).
