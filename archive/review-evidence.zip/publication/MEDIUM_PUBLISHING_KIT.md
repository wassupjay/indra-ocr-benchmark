# Medium publishing kit: four-engine comparison

## Ready-to-edit story

Use MEDIUM_POST.md or open medium-post.html. The current story covers the completed Indra, Tesseract 5, EasyOCR and PP-OCRv6 Tiny run. ARTICLE.md is the technical report. Earlier three-engine/medium-Paddle results remain separate historical evidence.

**Title:** CPU OCR Benchmark: Indra vs Tesseract, EasyOCR and PaddleOCR

**Subtitle:** Four engines, one Windows CPU, three charts.

**Alternative headline:** I Compared 4 OCR Engines. One Used Nearly 10 GiB of RAM.

**Search title:** Indra vs Tesseract vs EasyOCR vs PaddleOCR: CPU Benchmark

**Description:** Four OCR engines, 114 pages, one Windows CPU: measured text agreement, speed, memory and timing variation, with model configurations and audited results.

**Suggested topics:** OCR; Computer Vision; Python; Machine Learning; Software Engineering. Choose available relevant topics, rather than tagging unrelated audiences.

These are editorial suggestions, not experimentally proven click-through-rate winners. No traffic or Boost is guaranteed.

## Images and transfer to Medium

Use chart-speed.png as the preview/opening image, followed by chart-word-errors.png and chart-memory.png. Captions and alt text are in the post. All three are original aggregate-data charts; no book page is included.

Copy the title, subtitle and body from the HTML preview into a Medium draft, then upload the three charts separately. Local image paths do not automatically become Medium uploads. Check headings, captions and mobile preview inside Medium before publishing. Nothing has been posted here.

## Scope and authorship

Keep the opening AI-drafting disclosure and the AI-assistance captions. This substantially AI-drafted version should remain unpaywalled under Medium's current policy. Edit the wording to reflect your own experience and judgment; do not invent anecdotes or remove disclosure to imply human-only authorship.

The reference is unverified embedded PDF text: use text agreement, not independently verified accuracy. Indra led this current run, but its cross-session speed drift remains unexplained. EasyOCR's results belong to this particular English CRAFT/english_g2 configuration with requested default dynamic quantization. Tiny is not the previously tested medium model. Do not call any engine universally best from this one book.

All four completed three passes without execution failures, all 456 saved first-pass predictions were rescored, and every engine's normalized output was stable across the current passes. Detailed resource, initialization and bootstrap statistics are retained. Engine setup is not true cold-start latency; Tesseract loads its OCR model inside each timed CLI call.

## Release link and optional launch copy

The post says that the review archive is not publicly hosted. Replace that sentence only after a real verified download URL exists. Do not insert a fake repository URL or broken placeholder. Use the latest timestamped ZIP in publication; old ZIPs preserve earlier experiments/source versions.

**Short launch draft:** I tested Indra, Tesseract, EasyOCR and PaddleOCR Tiny on the same 114 page images, CPU only. Indra led this run on speed and reference-text agreement; Tesseract had the smallest memory footprint. The write-up includes three passes per engine, memory use, exact configurations and an unexplained cross-session speed difference. This is a single-book case study with an unverified PDF-text reference.

Append the actual Medium URL after publication. This launch text has not been sent anywhere.

## Medium guidance consulted

- [Story publishing](https://help.medium.com/hc/en-us/articles/225168768-Writing-and-publishing-your-first-story)
- [Display titles and subtitles](https://help.medium.com/hc/en-us/articles/214895188-Custom-titles-subtitles)
- [Distribution guidelines](https://help.medium.com/hc/en-us/articles/360006362473-Medium-s-Distribution-Guidelines-How-curators-review-stories-for-Boost-General-and-Network-Distribution)
- [AI content and disclosure](https://help.medium.com/hc/en-us/articles/22576852947223-Artificial-Intelligence-AI-content-policy)

## October 22 candidate-reference follow-up

The updated post includes a supplied AI-assisted transcription comparison, exclusions of 15 flagged pages and quote-style sensitivity. Do not describe either reference as independently verified ground truth. Original PDF-layer results and CPU timings remain separate. The raw supplied transcription and local word-difference report stay out of the public archive.

## Editorial update: October 22

Lead with the CPU OCR comparison and practical speed/memory trade-offs. Engine names and CPU OCR appear naturally in the title; no keyword stuffing or universal-best claim. Keep the two reference analyses separate. This i7-12700K / 96 GiB machine is not an entry-level-PC benchmark.

Medium guidance rechecked October 22, 2026. Its distribution guidelines favor original, useful, appropriately sourced human storytelling and reject misleading headlines. Boost eligibility is not a checklist or promise. The author should review and edit the story in their own voice, drawing only on actual experience. Keep the generated-text disclosure in the first two paragraphs; a substantially AI-generated draft should remain unpaywalled. These changes cannot guarantee Medium distribution or Google rankings.

## Short visual edition (current)

MEDIUM_POST.md / medium-post.html now use three bar charts and a short body. MEDIUM_FULL_METHODS.md preserves the previous detailed article unchanged. Upload chart-speed.png, chart-word-errors.png and chart-memory.png, in that order. Use chart-speed.png as the preview image; medium-cover.png and cpu-four-results.png remain optional historical assets, not required for the short edition. The WER chart deliberately shows both candidate references, not verified accuracy. Keep the short limitations note and all captions. The word-error chart and RAM chart use linear zero-based axes.

The local full-methods link needs a real public destination before Medium publishing; do not publish a broken local file link. No hosting URL has been created. Notion is optional and has not been updated. Nothing has been posted to Medium.
