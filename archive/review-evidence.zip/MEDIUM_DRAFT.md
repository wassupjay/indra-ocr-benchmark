# Comparing Indra, Tesseract, and PaddleOCR on a Windows CPU

*Draft case study, October 18, 2026. Public annotated-document evaluation is still pending. The speed anomaly below is part of the result and must remain visible if this case study is published.*

Across 114 pages of one English book, Indra and PaddleOCR produced almost the same word error rate against the PDF's embedded text. Indra made 1,245 word edits; PaddleOCR made 1,267. That is a difference of 22 edits over 60,526 reference words.

The large difference was recorded runtime. PaddleOCR was unusually slow on this Windows setup. That needs investigation before turning these measurements into a general claim about OCR speed.

## What was tested

The machine has an Intel Core i7-12700K, 20 logical CPUs and approximately 95.75 GiB of installed RAM, running Windows build 26200. Each engine was configured for four CPU threads. That setting is not a hard operating-system limit on every library thread.

The engines were Indra 0.3.2, [Tesseract 5.5.3](https://github.com/tesseract-ocr/tesseract/releases) with English language data, and [PaddleOCR 3.7.0 with PP-OCRv6](https://github.com/PaddlePaddle/PaddleOCR/releases/tag/v3.7.0) medium detection and recognition models. PaddleOCR used PaddlePaddle 3.2.2: the 3.3.0 oneDNN/PIR path crashed during warmup on this machine, matching an [upstream runtime issue](https://github.com/PaddlePaddle/Paddle/issues/77340). Input/reference hashes, settings, versions and timings were saved. Indra model and Tesseract English-data hashes were recorded; the historical Paddle run recorded model names but did not hash its weights.

Every engine received the same 200-DPI RGB page images. Indra was forced into OCR mode and its plain recognized text was scored. None of the engines could read the source PDF's embedded text layer as input. Headers and footers counted for all three engines.

The reference was extracted separately with Poppler. Unicode normalization, whitespace collapsing and Markdown heading-prefix removal were applied consistently. Case, punctuation and numbers remained significant. There were no header/footer exclusion rules in this comparison.

## Text agreement results

| Engine | Word error rate | Character error rate | Word edits | First-pass failures |
|---|---:|---:|---:|---:|
| Indra | 2.057% | 0.585% | 1,245 | 0 |
| Tesseract | 2.462% | 0.679% | 1,490 | 0 |
| PaddleOCR | 2.093% | 0.619% | 1,267 | 0 |

These are agreement scores against an **unverified PDF text layer**. They are not independently verified OCR accuracy. Character and word error rates count substitutions, missing items and extra items relative to the reference length; they should not be casually converted into a probability of correct recognition.

The average also hides variation between pages. Indra had fewer word edits than PaddleOCR on 48 pages, tied on 10 and had more on 56. Their small overall difference does not support a clear accuracy-winner claim.

A descriptive [paired percentile bootstrap](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html) gave an Indra-minus-PaddleOCR WER difference interval of approximately −0.266 to +0.191 percentage points. It includes zero. This calculation resamples pages within one book; it does not establish performance across independent books or document types. The experiment used 5,000 resamples and a fixed seed.

## Recorded speed

Each engine had one first-page warmup, followed by three measured passes over the book. The table uses the median complete-pass duration. It measures serial image-to-text application throughput, including decoding the page image. It excludes model downloads, model loading, PDF rendering, scoring and writing results.

| Engine | Recorded pages/min | Median complete pass | First-pass page p50 | First-pass page p95 |
|---|---:|---:|---:|---:|
| Indra | 200.57 | 34.10 s | 0.311 s | 0.373 s |
| Tesseract | 58.78 | 116.38 s | 1.074 s | 1.356 s |
| PaddleOCR | 0.84 | 8,137.26 s | 76.452 s | 96.087 s |

**The PaddleOCR row is an observed Windows-runtime result, not an established optimized PaddleOCR speed.** Its first-pass maximum page latency was about 570 seconds. Initialization and warmup are excluded from the table, but historical CPU load, sleep events and full-run memory use were not recorded.

The integration also matters: Tesseract started a CLI process for each page. The Python models stayed loaded. Those process-start costs are included in Tesseract's application throughput.

## Investigating the PaddleOCR slowdown

A follow-up inspection confirmed that both PaddleOCR components selected `mkldnn` mode with four CPU threads. Its default detector was receiving full-resolution page tensors around 2,336 by 1,664 pixels. A bounded test with detector resizing reached both detector and recognizer stages but still timed out; a legacy execution-IR test did not resolve the slowdown within its limit either. These tests do not establish the precise kernel-level cause.

A separate, monitored worker timed out after 180 seconds and reached about 1.5 GiB of sampled process-tree RSS. Its sampled CPU consumption averaged approximately 3.6 busy cores over the whole worker. These figures include imports, loading and warmup. They are diagnostic measurements from a separate execution, not full-book peak-memory measurements.

The appropriate conclusion is that this runtime configuration needs more investigation. An attention-grabbing speed multiplier would hide that limitation.

## Checking the evaluation itself

A small synthetic control renders an original passage with known text using three font/blur variants. All three models reproduced all 372 reference words across the variants without a word or character edit. The passage is the same 124 words each time, so these are not three independent documents. This is a clean-print sanity check, not a general accuracy ranking.

The full PaddleOCR control worker hit its eight-minute cap after saving two predictions. Its third prediction was completed separately in a cold single-image diagnostic. The quality check combines the saved predictions but claims no combined PaddleOCR control throughput. The provenance and hashes are recorded in `eval/benchmarks/synthetic-control-v1/quality-validation.json`.

On that final control image, stage instrumentation measured about 35 seconds of detector inference and 129 seconds of recognizer inference. Recognition dominated that particular cold test. It does not establish the exact kernel-level cause of the Windows slowdown.

A later diagnostic on the identical image and medium models disabled oneDNN explicitly. It completed in 109.83 seconds, versus the earlier 164.61-second cold run, with zero word edits in both outputs. Detector time stayed near 38 seconds; recognizer time fell to 71 seconds. Plain CPU with legacy execution IR took 110.56 seconds, also with zero word edits. These individual runs suggest a backend-related performance problem, but do not establish a repeated speed improvement or replace the full-book results. A one-thread oneDNN test was stopped after 136 seconds while still in detection and was slower than the four-thread setting.

This control cannot stand in for scanned documents. A prepared follow-up uses dataset-provided English text annotations from [OmniDocBench](https://huggingface.co/datasets/opendatalab/OmniDocBench/blob/main/README.md). It supplies the same annotated text-region crops to every engine, so results must be labeled region recognition and regions/min, rather than full-page document parsing or an official OmniDocBench score. The download was blocked in the execution session, and no public-dataset results are claimed here.

## Reproduction and limits

The project preserves the page images, reference text, first-pass predictions, input hashes, engine settings, per-page edit counts and three complete-pass timings. All 342 saved first-pass predictions were rescored from their text files; their scores and timing calculations matched the recorded results. `publication-stats.md` contains error breakdowns and descriptive intervals; `page-stats.csv` contains the per-page data.

The shareable review package includes code, aggregate book metrics, an evidence audit and the original synthetic control images/predictions. Its files have SHA256 checksums. It excludes the commercial book and all its raw page images, text and predictions. Reproducing the book experiment requires a legally obtained copy matching the recorded PDF hash. The original Paddle weight hashes cannot be established retrospectively; the runner now records weight hashes and actual runtime settings for future experiments. Code and the permitted artifacts still need a public download location before readers can access the release.

The useful finding is narrow: on this English book, Indra and PaddleOCR were close in reference-text agreement, and Tesseract had a higher word error rate. The recorded Windows application runtimes differed considerably. General accuracy rankings and optimized speed claims need a diverse annotated test set and a validated PaddleOCR execution configuration.

